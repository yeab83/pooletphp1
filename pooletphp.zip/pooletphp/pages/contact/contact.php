<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">  <!-- Include any other necessary stylesheets -->
    
<link rel="stylesheet" type="text/css" href="../../css/contact.css">
</head>
<body>
<?php include '../../component/header/header.php'; ?>
<div class="contact-container">
    <div class="right-side">
        <form class="contact-form" action="submit.php" method="POST">
            <h2>Contact Us</h2>
            <input type="text" placeholder="Enter Your Name" name="name" required>
            <input type="email" placeholder="Enter Your Email" name="email" required>
            <textarea placeholder="Enter Your Comment" name="comment" required></textarea>
            <button type="submit">Submit</button>
        </form>
    </div>
    <div class="left-side">
        <p><i class="fa fa-phone"></i> Call Us</p>
        <a href="#">+251115584295</a>
        <p><i class="fa fa-map-marker"></i> Location</p>
        <a href="#">Addis Ababa, Bambis Tsehay mesel Tower-3rd Floor</a>
    </div>
    <img src="logo.png" alt="Company Logo" class="background-logo">
</div>

    </div>
    <?php include '../../component/footer1/footer1.php'; ?>
    <?php include '../../component/footer2/footer2.php'; ?>

</body>
</html>
