<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../../css/driver.css">
</head>
<body>
<?php include '../../component/header/header.php'; ?>

    <div class="driver-container">
        <div class="right-side">
            <form class="driver-form" method="post" action="">
                <h2>Sign Up To Driver</h2>
                <input type="text" placeholder="Enter Your First Name" name="name" required>
                <input type="text" placeholder="Enter Your Last Name" name="lastname" required>
                <input type="text" placeholder="Enter Your Phone Number" name="phone" required>
                <div class="radio-gender">
                    <input type="radio" value="Male" name="gender"> Male
                    <input type="radio" value="Female" name="gender"> Female
                </div>
                <input type="email" placeholder="Enter Your Email" name="email" required>
                <input type="password" placeholder="Enter Your Password" name="password" required>
                <button type="submit" name="submit">Sign Up</button>
                <div>
                    <p>Download Our Application!</p>
                </div>
            </form>
        </div>
        <div class="left-side">
            <div class="photo-section">
            <img src="../../image/aboutus.png" alt="" />
            </div>
            <div class="playestoredriver">
                <a href="https://play.google.com/store/apps/details?id=com.example.app" target="_blank" rel="noopener noreferrer" class="store-link">
                <img src="../../image/playstore.png" alt="Download on Play Store" />
                </a>
                <a href="https://apps.apple.com/us/app/example-app/id1234567890" target="_blank" rel="noopener noreferrer" class="store-link">
                <img src="../../image/applestore.png" alt="Download on Apple Store" />
                </a>
            </div>
        </div>
    </div>
    <?php include '../../component/footer1/footer1.php'; ?>
    <?php include '../../component/footer2/footer2.php'; ?>
</body>
</html>
