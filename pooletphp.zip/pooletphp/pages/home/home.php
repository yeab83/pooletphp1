<!DOCTYPE html>
<html>
<head>
  

</head>
<body>
<?php include '../../component/header/header.php'; ?>

    <div class="content">
        <?php include '../../component/head/body.php'; ?>
    </div>
    <div class="content">
        <?php include '../../component/carts/carts.php'; ?>
    </div>
    <div class="content">
        <?php include '../../component/car_and_text/car_and_text.php'; ?>
    </div> 
     <div class="content">
    <?php include '../../component/transparent/transparent.php'; ?>  
  </div>
  <div class="content">
    <?php include '../../component/footer1/footer1.php'; ?>  
  </div>
  <div class="content">
    <?php include '../../component/footer2/footer2.php'; ?>  
  </div>
    <!-- Other HTML content or scripts if needed -->
</body>
</html>
