<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" type="text/css" href="../../css/transparent.css">
</head>
<body>

<div class="transportation-container">
  <div class="phone left-phone">
    <h1>Get a ride in minutes!</h1>
    <p>
      Pick your destination, request a ride, meet your
      <br />
      driver, enjoy the journey
    </p>
  </div>
  <div class="phone right-phone">
    <img src="../../image/phontra.png" alt="Map indicating a route" />
    <img src="../../image/maptra.png" alt="Map indicating a route" />
  </div>
</div>
</body>
</html>