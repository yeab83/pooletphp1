<div class="header">
    <div class="logo">
        <img src="../../image/Pool_Logo.png" alt="">
        <button>☰</button>
    </div>

    <div class="phoneno">
        <img src="../../image/phoneno.png" alt="">
    </div>
    <nav class="header-nav">
        <ul>
            <li><a href="/pooletphp/pages/home/home.php">Home</a></li>
            <li><a href="/pooletphp/pages/contact/contact.php">Contact</a></li>
            <li><a href="/pooletphp/pages/aboutus/aboutus.php">About Us</a></li>
            <li><a href="/pooletphp/pages/driver/driver.php">Driver</a></li>
            <li><a href="/pooletphp/pages/ride/ride.php">Ride</a></li>
        </ul>
    </nav>
</div>

