<!DOCTYPE html>
<html>
<head>
    <title>pool</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" type="text/css" href="../../css/header.css">
</head>
<body>
    <?php include 'header_content.php'; 
    ?>
    <script>
    const menuButton = document.querySelector('.logo button');
    const headerNav = document.querySelector('.header-nav');

    menuButton.addEventListener('click', () => {
      headerNav.classList.toggle('active');
    });
  </script>
</body>
</html>
