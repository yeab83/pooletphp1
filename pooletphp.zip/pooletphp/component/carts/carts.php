<!DOCTYPE html>
<html>
<head>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../css/carts.css">
</head>
<body>
    <!-- Include your PHP-generated content here -->
    <div class="dashboardpage">
    <div class="wrapper">
        <div class="card-holder">
            <div class="wrapper">
                <div class="card">
                    <h1>Faster pick-up</h1>
                    <h3>We have your contract already prepared</h3>
                    <div class="carticon">
                        <img src="../../image/fast.svg" alt="" />
                    </div>
                </div>
                <div class="card">
                    <h1>Secured and Safe</h1>
                    <h3>find the safest and finest ride</h3>
                    <div class="carticon">
                        <img src="../../image/sec.svg" alt="" />
                    </div>
                </div>
                <div class="card">
                    <h1>Better service</h1>
                    <h3>We know you better, we serve you better</h3>
                    <div class="carticon">
                        <img src="../../image/better.svg" alt="" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
