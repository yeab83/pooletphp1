<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" type="text/css" href="../../css/footer1.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">  <!-- Include any other necessary stylesheets -->
</head>
<body>
  <footer class="footer">
    <div class="column">
      <br />
      <br />

      <p>Follow us on social media:</p>
      <div class="social-icons">
        <a href="#">
          <i class="fa fa-facebook fa-2x"></i>
        </a>
        <a href="#">
          <i class="fa fa-instagram fa-2x"></i>
        </a>
        <a href="#">
          <i class="fa fa-twitter fa-2x"></i>
        </a>
      </div>
      <div class="btn-button1">
        <button class="button1">find our location</button>
      </div>
    </div>
    <div class="column">
      <a href="#">
      <i class="fa fa-whatsapp fa-2x"></i>
      </a>
      <p>WhatsApp Support</p>
      <div class="socialtext">
        Add us on WhatsApp & send <br />
        queries for instant reply.
      </div>
      <div class="btn-button1">
        <button class="button1">251948342002</button>
      </div>
    </div>
    <div class="column">
      <br />
      <br />

      <p>Live Chat</p>
      <a href="#">
      <i class="fa fa-telegram" ></i>
      </a>
      <div class="btn-button1">
        <button class="button1">Send Message</button>
      </div>
    </div>
  </footer>
</body>
</html>
