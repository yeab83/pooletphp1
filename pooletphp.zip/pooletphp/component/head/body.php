<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" type="text/css" href="../../css/body.css">
</head>
<body>
    <!-- Include your PHP-generated content here -->
    <div class="container">
    <div class="wapper">
        <div class="text-half">
            <p>
            The fast,affordable way to ride.
            </p>
            <h4>Download the Pool app</h4>
            <a href="https://play.google.com/store/apps/details?id=com.example.app"
               target="_blank"
               rel="noopener noreferrer"
               class="store-link">
                <img src="../../image/playstore.png" alt="Download on Play Store" />
            </a>
            <a href="https://apps.apple.com/us/app/example-app/id1234567890"
               target="_blank"
               rel="noopener noreferrer"
               class="store-link">
                <img src="../../image/applestore.png" alt="Download on Apple Store" />
            </a>
        </div>
    </div>
    <div class="image-half">
        <img src="../../image/addis-ababa.png" alt="Half Image" />
        <div class="logo-overlay"></div>
    </div>
</div>

</body>
</html>
