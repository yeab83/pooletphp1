<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">  <!-- Include any other necessary stylesheets -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" type="text/css" href="../../css/car_and_text.css">
</head>
<body>
    <!-- Include your PHP-generated content here -->
    <div class="new">
        <div class="top">
            <h1>Available Services</h1>
        </div>
        <div class="wrapper">
            <div class="carscontainer">
                <div class="carsimage-half">
                    <img src="../../image/car1.png" alt="Half Image" />
                </div>
                <div class="cartext-half">
                    <h1>POOL</h1>
                    <div class="details">
                        <div class="detail">
                            <div class="icon">
                                <img src="../../image/seat.png" alt="" />
                            </div>
                            <a>Seat:4</a>
                        </div>
                        <div class="detail">
                            <div class="icon">
                                <img src="../../image/edit.png" alt="" />
                            </div>
                            <a>Suitcase:2</a>
                        </div>
                    </div>
                    <p>
                        economy ride best for daily ride,
                        <br />
                        also can order with 3 other friends
                    </p>
                    <button class="button">Book Now</button>
                </div>
            </div>
            
            <!-- Repeat the same structure for other car containers -->

         
        
        <div class="wrapper">
            <div class="carscontainer">
                <div class="carsimage-half">
                    <img src="../../image/car2.png" alt="Half Image" />
                </div>
                <div class="cartext-half">
                    <h1>SUV/MINIVAN</h1>
                    <div class="details">
                        <div class="detail">
                            <div class="icon">
                                <img src="../../image/seat.png" alt="" />
                            </div>
                            <a>Seats:6/7</a>
                        </div>
                        <div class="detail">
                            <div class="icon">
                                <img src="../../image/edit.png" alt="" />
                            </div>
                            <a>Suitcase:2</a>
                        </div>
                    </div>
                    <p>
                        economy ride best for daily ride,
                        <br />
                        also can order with 3 other friends
                    </p>
                    <button class="button">Book Now</button>
                </div>
            </div>

            <!-- Repeat the same structure for other car containers -->

            
       
        <div class="wrapper">
            <div class="carscontainer">
                <div class="carsimage-half">
                    <img src="../../image/car2.png" alt="Half Image" />
                </div>
                <div class="cartext-half">
                    <h1>Minibus</h1>
                    <div class="details">
                        <div class="detail">
                            <div class="icon">
                                <img src="../../image/seat.png" alt="" />
                            </div>
                            <a>Seats:12/15</a>
                        </div>
                        <div class="detail">
                            <div class="icon">
                                <img src="../../image/edit.png" alt="" />
                            </div>
                            <a>Suitcase:2</a>
                        </div>
                    </div>
                    <p>
                        economy ride best for daily ride,
                        <br />
                        also can order with 3 other friends
                    </p>
                    <button class="button">Book Now</button>
                </div>
            </div>

            <!-- Repeat the same structure for other car containers -->

        </div>
    </div>
</body>
</html>
