<!-- footer2.php -->
<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" type="text/css" href="../../css/footer2.css">
</head>
<body>

  <footer class="center-footer">
    <p>© 2023 Pool Technology</p>
    <div class="logos">
    <img src="../../image/Pool_Logo.png" alt="" />
      <!-- Use any icon or text for the button -->
    </div>
  </footer>
</body>
</html>
